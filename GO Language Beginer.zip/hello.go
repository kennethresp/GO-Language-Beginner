package main

import (
	"fmt"
	"math"
)
import "errors"
func main() {
//mt.Printf("helloword, world\n")
/////Println("stop")

//ar ken int=78
	result,err:=sqrt(-16)
if err !=nil{
fmt.Println(err)
}else{fmt.Println(result)}}
func sqrt(x float64)(float64, error){

if x<0 {
return 0, errors.New("Undefined Nagative number")
       }
return math.Sqrt(x),nil
}